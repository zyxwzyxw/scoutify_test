const YEAR = 2023
const COMP = "test"
const GAME_TYPE = "Q"
const gameStart = new Date("September 29, 2023")
const gameEnd = new Date("October 4, 2023")

export {
    YEAR,
    COMP,
    GAME_TYPE,
    gameStart,
    gameEnd
}